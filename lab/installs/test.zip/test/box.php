<?php
	
	$brancher->auth() or die(include_once("modules/auth/alert.html"));
	
	$handle = "b".time();
	ob_start();
	
?>

<form id="<?php print($handle); ?>" onsubmit="return saveSettingsBox(this)" class="box"  onmousedown="boxList.focus(this)" style="max-width:780px">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<div class="box-title">
		<img title="Close" class="close-box" onclick="boxList.drop('<?php print($handle); ?>')" src="/images/close_box.png" align="right"/>
		
	</div>
	<div class="box-body">
		
	</div>
	<div class="box-footer">
		
	</div>
</form>

<?php	

	$tpl = ob_get_contents();
	ob_end_clean();
	
	$tpl = new HTMLDocument($tpl);
	
	$wordlist = new Wordlist(array("base"));
	$wordlist->translateDocument($tpl);
	
	print($tpl);

?>