<?php
	
	$brancher->auth() or die(include_once("modules/auth/alert.html"));
	
	$rows = $mySQL->query("SELECT SQL_CALC_FOUND_ROWS * FROM `gb_keywords`");
	
	$color=16777215;
	foreach($rows as $row){
		$keywords .= "
		<tr bgcolor='#".dechex($color^=1052688)."'>
			<td onclick='showWordlistBox(this.next())' bgcolor='white' class='tool'>W</td>
			<td>".$row['tag']."</td>
			<td>".$row['id']."</td>
			<td>".$row['rating']."</td>
			<td>".$row['use']."</td>
		</tr>";
	}	
	$used = reset($mySQL->single_row("SELECT FOUND_ROWS()"));
	
	$fields = reset($mySQL->group_rows("SHOW COLUMNS FROM `gb_tagination`"));
	
	$handle = "b".time();
	ob_start();
	
?>

<form id="<?php print($handle); ?>" onsubmit="return saveSettingsBox(this)" class="box"  onmousedown="boxList.focus(this)" style="max-width:720px">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<div class="box-title">
		<img title="Close" class="close-box" onclick="boxList.drop('<?php print($handle); ?>')" src="/images/close_box.png" align="right"/>
		Keywords:
	</div>
	<div class="box-body">
		<table width="100%" rules="cols" cellpadding="2" cellspacing="0" bordercolor="#CCC">
			<thead>
				<tr bgcolor="#555" style="color:white">
					<th width="30">
					</th><th>Keyword</th>
					<th width="80">ID</th>
					<th width="110">Used count</th>
					<th width="180">Last use</th>
				</tr>
			</thead>
			<tbody align="center">
<?php
	print($keywords);
?>
			</tbody>
		</table>
	</div>
	<div class="box-footer">
		<span id="keycount"><?php print("Used: ".$used."/".((count($fields)-1) * 32)); ?></span>
		<button onclick="tagination_addSection()">Add 32 cells</button>
	</div>
</form>

<?php	

	$tpl = ob_get_contents();
	ob_end_clean();
	
	$tpl = new HTMLDocument($tpl);
	
	$wordlist = new Wordlist(array("base"));
	$wordlist->translateDocument($tpl);
	
	print($tpl);

?>